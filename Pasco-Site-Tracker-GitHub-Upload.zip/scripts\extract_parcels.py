from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any

import openpyxl


WORKSPACE = Path(__file__).resolve().parents[1]
DEFAULT_EXCEL = Path(
    r"C:\Users\Owner\Documents\Business\Tampa Database\Data\Pasco\RT 52 MASTER TRACKER 5.18.26.xlsx"
)
DEFAULT_HTML = Path(r"C:\Users\Owner\Downloads\pasco_site_tracker (6).html")
OUTPUT_DIR = WORKSPACE / "data"
OUTPUT_JSON = OUTPUT_DIR / "parcels.json"
OUTPUT_WARNINGS = OUTPUT_DIR / "import_warnings.json"


def clean_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    text = str(value).strip()
    return re.sub(r"\s+", " ", text)


def number_or_none(value: Any) -> float | int | None:
    if value is None or value == "":
        return None
    if isinstance(value, (int, float)):
        if isinstance(value, float) and value.is_integer():
            return int(value)
        return value
    text = re.sub(r"[^0-9.\-]", "", str(value))
    if not text:
        return None
    number = float(text)
    return int(number) if number.is_integer() else number


def money_or_none(value: Any) -> float | int | None:
    return number_or_none(value)


def date_text(value: Any) -> str:
    if value is None:
        return ""
    if hasattr(value, "strftime"):
        return value.strftime("%Y-%m-%d")
    text = clean_text(value)
    return text.split(" ")[0] if text else ""


def address_display(address: str, city: str, zipcode: str) -> str:
    pieces = []
    if address:
        pieces.append(address)
    if city:
        pieces.append(city)
    state_zip = "FL"
    if zipcode:
        state_zip += f" {zipcode}"
    if city or zipcode:
        pieces.append(state_zip)
    return ", ".join(pieces) if pieces else "Unknown Address"


def parcel_id(row: dict[str, Any]) -> str:
    link = clean_text(row["link"]).lower()
    if link:
        seed = link
    else:
        seed = "|".join(
            [
                clean_text(row["parcel_address"]).lower(),
                clean_text(row["city"]).lower(),
                clean_text(row["zip"]).lower(),
                str(row["lat"]),
                str(row["lng"]),
                clean_text(row["owner_name"]).lower(),
            ]
        )
    return "pst_" + hashlib.sha1(seed.encode("utf-8")).hexdigest()[:12]


def load_statuses_from_html(path: Path) -> list[str]:
    if not path.exists():
        return []
    text = path.read_text(encoding="utf-8", errors="replace")
    match = re.search(r"const PARCELS = (\[.*?\]);\s*\n\s*let liveData", text, re.S)
    if not match:
        return []
    parcels = json.loads(match.group(1))
    statuses = []
    for parcel in parcels:
        status = clean_text(parcel.get("status")) or "Pending"
        statuses.append("Not Started" if status == "Pending" else status)
    return statuses


def load_first_sheet(path: Path) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    workbook = openpyxl.load_workbook(path, data_only=True, read_only=True)
    sheet = workbook.worksheets[0]
    rows = list(sheet.iter_rows(values_only=True))
    nonempty_rows = [
        (row_number + 1, row)
        for row_number, row in enumerate(rows)
        if any(cell is not None and str(cell).strip() for cell in row)
    ]
    header_row = nonempty_rows[0][1]
    headers = [clean_text(cell) for cell in header_row]
    data_rows = nonempty_rows[1:]

    raw_records: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []

    for excel_row, row in data_rows:
        def cell(index: int) -> Any:
            return row[index] if index < len(row) else None

        lat = number_or_none(cell(11))
        lng = number_or_none(cell(12))
        record = {
            "source_row": excel_row,
            "link": clean_text(cell(0)),
            "type": clean_text(cell(1)) or "Land",
            "parcel_address": clean_text(cell(2)),
            "city": clean_text(cell(3)),
            "zip": clean_text(cell(4)),
            "notes": clean_text(cell(5)),
            "sale_date": date_text(cell(6)),
            "sold_price": money_or_none(cell(7)),
            "zoning": clean_text(cell(8)),
            "opp_zone": clean_text(cell(9)) or "No",
            "acres": number_or_none(cell(10)),
            "lat": lat,
            "lng": lng,
            "assess_val": money_or_none(cell(13)),
            "taxes": money_or_none(cell(14)),
            "owner_name": clean_text(cell(15)),
            "mailing_address": clean_text(cell(16)),
            "mailing_city": clean_text(cell(17)),
            "mailing_state": clean_text(cell(18)),
            "mailing_zip": clean_text(cell(19)),
            "contact_name": clean_text(cell(20)),
            "phones": [clean_text(cell(i)) for i in range(21, 26) if clean_text(cell(i))],
            "emails": [clean_text(cell(i)) for i in range(26, 31) if clean_text(cell(i))],
            "extra_fields": {
                headers[i]: clean_text(cell(i))
                for i in range(31, len(headers))
                if i < len(row) and headers[i] and clean_text(cell(i))
            },
        }
        if lat is None or lng is None:
            warnings.append(
                {
                    "sourceRow": excel_row,
                    "reason": "Missing latitude or longitude",
                    "address": record["parcel_address"],
                    "notes": record["notes"],
                }
            )
            continue
        raw_records.append(record)

    return raw_records, warnings


def normalize_records(records: list[dict[str, Any]], statuses: list[str]) -> list[dict[str, Any]]:
    parcels: list[dict[str, Any]] = []
    for index, record in enumerate(records):
        display = address_display(record["parcel_address"], record["city"], record["zip"])
        status = statuses[index] if index < len(statuses) else "Not Started"
        parcels.append(
            {
                "id": parcel_id(record),
                "source": {
                    "file": DEFAULT_EXCEL.name,
                    "sheet": "Pasco RT 52",
                    "row": record["source_row"],
                },
                "status": status,
                "category": record["type"],
                "priority": "Normal",
                "ballInCourt": "None",
                "nextAction": "",
                "nextActionDue": "",
                "assemblageGroup": "",
                "displayAddress": display,
                "addressLine": record["parcel_address"],
                "city": record["city"],
                "state": "FL",
                "zip": record["zip"],
                "lat": record["lat"],
                "lng": record["lng"],
                "type": record["type"],
                "zoning": record["zoning"],
                "oppZone": record["opp_zone"],
                "acres": record["acres"],
                "assessedValue": record["assess_val"],
                "taxes": record["taxes"],
                "saleDate": record["sale_date"],
                "soldPrice": record["sold_price"],
                "owner": {
                    "name": record["owner_name"],
                    "mailingAddress": record["mailing_address"],
                    "mailingCity": record["mailing_city"],
                    "mailingState": record["mailing_state"],
                    "mailingZip": record["mailing_zip"],
                },
                "contact": {
                    "name": record["contact_name"],
                    "phones": record["phones"],
                    "emails": record["emails"],
                },
                "notes": record["notes"],
                "activity": [],
                "comments": [],
                "actions": [],
                "lastContacted": "",
                "crexiLink": record["link"],
                "documents": [],
                "extraFields": record.get("extra_fields", {}),
                "archived": False,
                "createdAt": "",
                "updatedAt": "",
            }
        )
    return parcels


def main() -> None:
    records, warnings = load_first_sheet(DEFAULT_EXCEL)
    statuses = load_statuses_from_html(DEFAULT_HTML)
    parcels = normalize_records(records, statuses)

    OUTPUT_DIR.mkdir(exist_ok=True)
    OUTPUT_JSON.write_text(json.dumps(parcels, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
    OUTPUT_WARNINGS.write_text(json.dumps(warnings, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
    print(f"Wrote {len(parcels)} parcels to {OUTPUT_JSON}")
    print(f"Wrote {len(warnings)} import warning(s) to {OUTPUT_WARNINGS}")


if __name__ == "__main__":
    main()
